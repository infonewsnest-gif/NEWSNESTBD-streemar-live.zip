# NewsNestBD Live Studio - Android RTMP Live Streaming Studio

NewsNestBD Live Studio হলো একটি সম্পূর্ণ Android Jetpack Compose ভিত্তিক লাইভ স্ট্রিমিং অ্যাপ্লিকেশন। এটি দিয়ে ফেসবুক (Facebook Live) এবং ইউটিউবে (YouTube Live) আরটিএমপি (RTMP/RTMPS) প্রটোকলে সরাসরি মোবাইল ক্যামেরা অথবা ভিডিও ফাইল থেকে ব্রেকিং নিউজ মারকুই টিকার ব্যানার সহ লাইভ সম্প্রচার করা যায়।

---

## 🚀 সরাসরি APK তৈরি করার উপায় (How to Create APK)

### পদ্ধতি ১: GitHub Actions দিয়ে বিনামূল্যে স্বয়ংক্রিয় APK তৈরি (সবচেয়ে সহজ)
আপনার কম্পিউটারে Android Studio না থাকলেও গিটহাবের ক্লাউড সার্ভারে ২ মিনিটে APK বিল্ড করা সম্ভব:

1. আপনার GitHub অ্যাকাউন্টে একটি নতুন Repository তৈরি করুন (Private বা Public)।
2. এই ZIP ফাইলের সমস্ত ফাইল আনজিপ করে আপনার রিপোজিটরিতে আপলোড করুন বা Git দিয়ে পুশ করুন:
   ```bash
   git init
   git add .
   git commit -m "Initial NewsNestBD Live Studio"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. গিটহাবের রিপোজিটরি ওপেন করে **"Actions"** ট্যাবে যান।
4. দেখতে পাবেন **"Build Android APK"** ওয়ার্কফ্লোটি স্বয়ংক্রিয়ভাবে চলছে।
5. বিল্ড শেষ হলে (সবুজ টিক মার্ক আসার পর) রানটিতে ক্লিক করুন এবং নিচে **"Artifacts"** সেকশন থেকে **app-debug.apk** ডাউনলোড করে সরাসরি ফোনে ইনস্টল করে নিন!

---

### পদ্ধতি ২: Android Studio দিয়ে কম্পিউটারে APK তৈরি
1. আপনার কম্পিউটারে **Android Studio** (Hedgehog বা নতুন) ইনস্টল করুন।
2. Android Studio ওপেন করে **"Open"** অপশনে গিয়ে এই ফোল্ডারটি সিলেক্ট করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. মেনু বার থেকে ক্লিক করুন:
   `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. কয়েক সেকেন্ডে APK তৈরি হয়ে যাবে। পপআপে **"locate"** বাটনে ক্লিক করলে `app/build/outputs/apk/debug/app-debug.apk` ফাইলটি পাবেন।

---

### পদ্ধতি ৩: টার্মিনাল বা কমান্ড লাইনে বিল্ড
```bash
# Linux / macOS
chmod +x gradlew
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```
বিল্ড শেষে APK ফাইলটির লোকেশন:
`app/build/outputs/apk/debug/app-debug.apk`

---

## ⚙️ কনফিগারেশন সেটিংস (Configuration)
- **Package Name**: `com.streamcast.studio`
- **Application ID**: `000000000000000`
- **Client Token**: `replace_with_your_client_token`
- **Breaking News Banner**: `ব্রেকিং নিউজ: নিউজ নেস্ট লাইভ সম্প্রচার চলছে...`
- **Stream Protocols**: Facebook RTMPS (`rtmps://live-api-s.facebook.com:443/rtmp/`), YouTube RTMP (`rtmp://a.rtmp.youtube.com/live2/`)
